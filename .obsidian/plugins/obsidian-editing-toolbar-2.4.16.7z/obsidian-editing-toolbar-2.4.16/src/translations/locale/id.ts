// Bahasa Indonesia

export default {};
