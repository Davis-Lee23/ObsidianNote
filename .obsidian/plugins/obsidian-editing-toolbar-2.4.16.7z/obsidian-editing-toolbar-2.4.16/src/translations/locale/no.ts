// Norsk

export default {};
