// русский

export default {};
