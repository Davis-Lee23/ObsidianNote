// British English

export default {};
