// język polski

export default {};
