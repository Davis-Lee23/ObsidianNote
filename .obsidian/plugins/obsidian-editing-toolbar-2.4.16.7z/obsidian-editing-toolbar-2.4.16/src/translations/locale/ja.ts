// 日本語

export default {};
